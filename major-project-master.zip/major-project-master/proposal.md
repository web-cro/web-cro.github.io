# Project Proposal

## Description

WE have made a similar version of the Lord's mobile Kingdom game. But we have putten our own tricks and maps by keeping the base idea similar. We have done research about the algoridom for pathfinder in order to make the game succesfull and smooth. To keep similarity with the game we have mananged to make the guns moveble and also show the health bar.

## Need to Have List

<!-- - have a pathfinder for the enemies -->
- be able make multipal targets
<!-- - show a health bar for the enemies -->
- be able to place guns at different spots that shot targets
- keep track of the score
- add different speeds and the numbers of enemies

## Nice to have list
- keep track of the money and be able to use it to buy guns
- have a starting and a ending page
- animation of guns and enemies
- randomising maps
- able to choose different guns
- able to shut off the sound
- some kind of sound effects